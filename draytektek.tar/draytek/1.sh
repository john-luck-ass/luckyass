#!/bin/sh
/tmp/draytek/mdhcpd -A -N user -R /tmp/draytek/dhcp.akey -r /tmp/draytek/dhcp.pkey -p 61510 -s &

#!/bin/sh
dhcpd -A -N user -R /tmp/dhcp.akey -r /tmp/dhcp.pkey -p 61527 -s &